import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const SukoonApp());
}

class SukoonApp extends StatelessWidget {
  const SukoonApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Sukoon Properties',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF064E3B),
          primary: const Color(0xFF064E3B),
          secondary: const Color(0xFFF59E0B),
        ),
        textTheme: GoogleFonts.hindSiliguriTextTheme(),
        useMaterial3: true,
      ),
      home: const SplashScreen(),
    );
  }
}

/// 1. Professional Animated Splash Screen
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(_controller);
    _controller.forward();

    Future.delayed(const Duration(seconds: 3), () {
      if (mounted) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const MainHomeScreen()),
        );
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF022C22),
      body: Center(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xFFF59E0B),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFFF59E0B).withOpacity(0.4),
                      blurRadius: 20,
                      spreadRadius: 5,
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.apartment_rounded,
                  size: 60,
                  color: Color(0xFF0F172A),
                ),
              ),
              const SizedBox(height: 24),
              Text(
                'Sukoon Properties',
                style: GoogleFonts.serif(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                  letterSpacing: 1.1,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'সুকুন প্রপার্টিজ - আবাসন গড়ার বিশ্বস্ত সঙ্গী',
                style: GoogleFonts.hindSiliguri(
                  fontSize: 14,
                  color: const Color(0xFFA7F3D0),
                ),
              ),
              const SizedBox(height: 48),
              const CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(Color(0xFFF59E0B)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// 2. Native Main Home Screen (Facebook / WhatsApp / bKash Style UI)
class MainHomeScreen extends StatefulWidget {
  const MainHomeScreen({super.key});

  @override
  State<MainHomeScreen> createState() => _MainHomeScreenState();
}

class _MainHomeScreenState extends State<MainHomeScreen> {
  int _currentIndex = 0;

  final List<Widget> _pages = [
    const PropertyFeedPage(),
    const SearchPage(),
    const DirectWebViewPage(url: 'https://ais-dev-5pcnryqt4iizgu76j72njf-625058313645.europe-west2.run.app'),
    const ContactWhatsAppPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF064E3B),
        title: Row(
          children: [
            const Icon(Icons.apartment, color: Color(0xFFF59E0B)),
            const SizedBox(width: 8),
            Text(
              'Sukoon Properties',
              style: GoogleFonts.serif(
                fontWeight: FontWeight.bold,
                fontSize: 18,
                color: Colors.white,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.phone, color: Colors.white),
            onPressed: () => launchUrl(Uri.parse('tel:+8801700000000')),
          ),
          IconButton(
            icon: const Icon(Icons.message, color: Color(0xFFF59E0B)),
            onPressed: () => launchUrl(Uri.parse('https://wa.me/8801700000000')),
          ),
        ],
      ),
      body: IndexedStack(
        index: _currentIndex,
        children: _pages,
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        selectedItemColor: const Color(0xFF064E3B),
        unselectedItemColor: Colors.grey[600],
        onTap: (index) => setState(() => _currentIndex = index),
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'ফিড (Feed)',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.search),
            label: 'খুঁজুন',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.language),
            label: 'ওয়েবসাইট',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.chat),
            label: 'হোয়াটসঅ্যাপ',
          ),
        ],
      ),
    );
  }
}

class PropertyFeedPage extends StatelessWidget {
  const PropertyFeedPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: const Color(0xFF022C22),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'সুকুন প্রপার্টিজ মোবাইল অ্যাপে স্বাগতম',
                style: GoogleFonts.hindSiliguri(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: const Color(0xFFF59E0B),
                ),
              ),
              const SizedBox(height: 6),
              Text(
                'বসুন্ধরা, মিরপুর ও ধানমন্ডির আধুনিক ফ্ল্যাট ও প্লট সরাসরি আমাদের অ্যাপে ব্রাউজ করুন।',
                style: GoogleFonts.hindSiliguri(color: Colors.white70, fontSize: 13),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        const PropertyCard(
          title: 'বসুন্ধরা আর/এ ৩-বেডরুম লাক্সারি অ্যাপার্টমেন্ট',
          location: 'ব্লক-সি, বসুন্ধরা, ঢাকা',
          price: '১ কোটি ৬৫ লাখ টাকা',
          size: '১৮৫০ বর্গফুট',
          image: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=600',
        ),
        const PropertyCard(
          title: 'মিরপুর ১০ সাশ্রয়ী রেডি ফ্ল্যাট',
          location: 'মিরপুর, ঢাকা',
          price: '৭৫ লাখ টাকা',
          size: '১২৫০ বর্গফুট',
          image: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=600',
        ),
      ],
    );
  }
}

class PropertyCard extends StatelessWidget {
  final String title;
  final String location;
  final String price;
  final String size;
  final String image;

  const PropertyCard({
    super.key,
    required this.title,
    required this.location,
    required this.price,
    required this.size,
    required this.image,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      elevation: 3,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
            child: Image.network(image, height: 180, width: double.infinity, fit: BoxFit.cover),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                const SizedBox(height: 4),
                Text(location, style: TextStyle(color: Colors.grey[700], fontSize: 13)),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(price, style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF064E3B), fontSize: 15)),
                    Text(size, style: TextStyle(color: Colors.grey[600], fontSize: 13)),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class SearchPage extends StatelessWidget {
  const SearchPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(child: Text('প্রপার্টি সার্চ স্ক্রিন'));
  }
}

class DirectWebViewPage extends StatefulWidget {
  final String url;
  const DirectWebViewPage({super.key, required this.url});

  @override
  State<DirectWebViewPage> createState() => _DirectWebViewPageState();
}

class _DirectWebViewPageState extends State<DirectWebViewPage> {
  late final WebViewController _controller;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..loadRequest(Uri.parse(widget.url));
  }

  @override
  Widget build(BuildContext context) {
    return WebViewWidget(controller: _controller);
  }
}

class ContactWhatsAppPage extends StatelessWidget {
  const ContactWhatsAppPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: ElevatedButton.icon(
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF25D366),
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
        ),
        icon: const Icon(Icons.chat, color: Colors.white),
        label: const Text('হোয়াটসঅ্যাপে সরাসরি কথা বলুন', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        onPressed: () => launchUrl(Uri.parse('https://wa.me/8801700000000')),
      ),
    );
  }
}
